package net.lab1024.sa.admin.module.business.sprinklermanager.statistic;


import lombok.extern.slf4j.Slf4j;
import net.lab1024.sa.base.common.domain.ResponseDTO;
import net.lab1024.sa.base.module.support.operatelog.annotation.OperateLog;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@OperateLog
public class StatisticController {

//    public ResponseDTO<String>

}
